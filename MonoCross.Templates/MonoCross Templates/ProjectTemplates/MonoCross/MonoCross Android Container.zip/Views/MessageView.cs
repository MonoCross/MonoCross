﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

using MonoCross.Navigation;
using MonoCross.Droid;

namespace $safeprojectname$.Views
{
    [Activity]
    public class MessageView : MXListActivityView<string>
    {
        public override void Render()
        {
            ListView.Adapter = new ArrayAdapter<String>(this, Android.Resource.Layout.SimpleListItem1, new string[] { Model });
        }
    }
}

