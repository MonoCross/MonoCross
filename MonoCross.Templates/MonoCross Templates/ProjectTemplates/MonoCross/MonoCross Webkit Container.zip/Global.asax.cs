﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

using MonoCross.Navigation;
using MonoCross.Webkit;

namespace $safeprojectname$
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.Ignore("favicon.ico");
            routes.MapRoute("", "{*mapUri}", new { controller = "App", action = "Render" });
        }

        protected void Application_Start()
        {
            RegisterRoutes(RouteTable.Routes);

            // initialize app
            // example: MXWebkitContainer.Initialize(new MyApp.App());

            // add views to container
            // example: MXWebkitContainer.AddView<string>(new Views.MyView(), ViewPerspective.Default);
        }
    }
}